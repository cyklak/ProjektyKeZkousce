package org.example.data.entities;

import jakarta.persistence.*;

import java.util.Date;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "PojistneUdalosti")
public class PojistnaUdalostEntity {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private long pojistnaUdalostId;

        @Column(nullable = false)
        private String NazevUdalosti;

        @Column(nullable = false)
        private Date datumUdalosti;

        @Column(columnDefinition = "TEXT", nullable = false)
        private String popisUdalosti;

        @ManyToMany (mappedBy = "seznamUdalosti")
        private List<PojisteniEntity> pojisteni;
        @Column
        private Long pojistenecId;


    public long getPojistnaUdalostId() {
        return pojistnaUdalostId;
    }

    public void setPojistnaUdalostId(long pojistnaUdalostId) {
        this.pojistnaUdalostId = pojistnaUdalostId;
    }

    public String getNazevUdalosti() {
        return NazevUdalosti;
    }

    public void setNazevUdalosti(String nazevUdalosti) {
        NazevUdalosti = nazevUdalosti;
    }

    public Date getDatumUdalosti() {
        return datumUdalosti;
    }

    public void setDatumUdalosti(Date datumUdalosti) {
        this.datumUdalosti = datumUdalosti;
    }

    public String getPopisUdalosti() {
        return popisUdalosti;
    }

    public void setPopisUdalosti(String popisUdalosti) {
        this.popisUdalosti = popisUdalosti;
    }

    public List<PojisteniEntity> getPojisteni() {
        return pojisteni;
    }

    public void setPojisteni(List<PojisteniEntity> pojisteni) {
        this.pojisteni = pojisteni;
    }

    public Long getPojistenecId() {
        return pojistenecId;
    }

    public void setPojistenecId(Long pojistenecId) {
        this.pojistenecId = pojistenecId;
    }


}
