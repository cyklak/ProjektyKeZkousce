package org.example.data.repositories.specification;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import lombok.RequiredArgsConstructor;
import org.example.data.entities.PojistenecEntity;
import org.example.data.entities.filter.PojistenecFilter;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

//@RequiredArgsConstructor
//public class PojistenecSpecification implements Specification<PojistenecEntity> {

   // private final PojistenecFilter filter;

   // @Override
   // public Predicate toPredicate(Root<PojistenecEntity> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
       // List<Predicate> predicates = new ArrayList<>();
    //}
//}
