package org.example.data.entities.filter;

import lombok.Data;

    @Data
    public class PojistenecFilter {

        private long pojistenecId = -1;
        private String jmeno = "";
        private String prijmeni;
        private String email;
        private String telefon;
        private String ulice;
        private String mesto;
        private String psc;

    }

