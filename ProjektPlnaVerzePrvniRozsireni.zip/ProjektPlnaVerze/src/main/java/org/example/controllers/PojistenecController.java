package org.example.controllers;
import jakarta.servlet.ServletException;
import jakarta.validation.Valid;
import org.example.data.entities.PojistenecEntity;
import org.example.data.entities.UserEntity;
import org.example.data.repositories.PojistenecRepository;
import org.example.data.repositories.UserRepository;
import org.example.models.dto.PojistenecDTO;
import org.example.models.dto.PojisteniDTO;
import org.example.models.dto.UserDTO;
import org.example.models.dto.mappers.PojistenecMapper;
import org.example.models.dto.mappers.PojisteniMapper;
import org.example.models.exceptions.PojistenecNotFoundException;
import org.example.models.services.PojistenecService;
import org.example.models.services.PojisteniService;
import org.example.models.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/pojistenci/")
public class PojistenecController {
    @Autowired
    private PojistenecMapper pojistenecMapper;

    @Autowired
    private UserService userService;

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private PojistenecService pojistenecService;

    @Autowired
    private PojisteniMapper pojisteniMapper;

    @Autowired
    private PojistenecRepository pojistenecRepository;
    @Autowired
    private PojisteniService pojisteniService;

    @Secured("ROLE_ADMIN")
    @GetMapping("stranka/{currentPage}")
    public String renderIndex(Model model,  @PathVariable int currentPage) {
        List<PojistenecDTO> pojistenci = pojistenecService.getPojistenci(currentPage -1);
        model.addAttribute("pojistenci", pojistenci);
        if (pojistenecRepository.count() > 10) {
            model.addAttribute("soucasnaStrana", currentPage);}
        if (pojistenecRepository.count() > (currentPage*10)) {
            model.addAttribute("pristiStrana", currentPage + 1);
            if (pojistenecRepository.count() > (currentPage*10) + 10) {
                model.addAttribute("prespristiStrana", currentPage + 2);}
        }
        if (currentPage > 1) {
            model.addAttribute("predchoziStrana", currentPage - 1);
            if (currentPage > 2) {
                model.addAttribute("predpredchoziStrana", currentPage - 2);
            }
        }
        return "pages/pojistenci/index";
    }
    @Secured({"ROLE_ADMIN", "ROLE_USER"})
    @GetMapping("novyPojistenec")
    public String renderNovyPojistenec(@ModelAttribute PojistenecDTO pojistenec, Model model) {
        model.addAttribute("novy", 1);
        model.addAttribute("novyPojistenec", "Nový pojištěnec");

        return "pages/pojistenci/novyPojistenec";
    }


    @Secured({"ROLE_ADMIN", "ROLE_USER"})
    @PostMapping("novyPojistenec")
    public String createNovyPojistenec(
            @Valid @ModelAttribute PojistenecDTO pojistenec,
            BindingResult result,
            RedirectAttributes redirectAttributes, Model model
    ) {
        if (result.hasErrors())
            return renderNovyPojistenec(pojistenec, model);
        UserEntity user = (UserEntity) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        PojistenecEntity entity = pojistenecService.create(pojistenec, user);
        user.setPojistenecEntity(entity);
        userRepository.save(user);
        redirectAttributes.addFlashAttribute("success", "Pojištěnec byl vytvořen.");
        if (!user.isAdmin()) {
            return "redirect:/home";
        }
        return "redirect:/pojistenci/stranka/1";
    }
    @Secured({"ROLE_ADMIN", "ROLE_USER"})
    @GetMapping
    public String renderDetailUser(
            Model model
    ) {
        UserEntity user = (UserEntity) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (user.isAdmin())
            return "redirect:/pojisteni/stranka/1";
        PojistenecDTO pojistenec = pojistenecService.getById(user.getPojistenecEntity().getPojistenecId());
        model.addAttribute("pojistenec", pojistenec);
        List<PojisteniDTO> pojisteni = pojisteniService.getAllByPojistenecId(user.getPojistenecEntity().getPojistenecId());
        model.addAttribute("pojisteni", pojisteni);
        model.addAttribute("user", user);
        model.addAttribute("pojistenci",1);
        model.addAttribute("mojePojisteniAktivni", "Moje pojištění ");

        return "pages/pojistenci/detail";
    }

    @Secured({"ROLE_ADMIN"})
    @GetMapping("{pojistenecId}")
    public String renderDetailAdmin (@PathVariable Long pojistenecId,
            Model model
    ) {
        PojistenecDTO pojistenec = pojistenecService.getById(pojistenecId);
        model.addAttribute("pojistenec", pojistenec);
        List<PojisteniDTO> pojisteni = pojisteniService.getAllByPojistenecId(pojistenecId);
        model.addAttribute("pojisteni", pojisteni);
        model.addAttribute("pojistenci",1);
        model.addAttribute("mojePojisteniAktivni", "Moje pojištění ");

        return "pages/pojistenci/detail";
    }
    @Secured({"ROLE_ADMIN", "ROLE_USER"})
    @GetMapping("edit/{pojistenecId}")
    public String renderEditForm(
            @PathVariable Long pojistenecId,
            PojistenecDTO pojistenec, Model model
    ) {
        PojistenecDTO fetchedPojistenec = pojistenecService.getById(pojistenecId);
        pojistenecMapper.updatePojistenecDTO(fetchedPojistenec, pojistenec);
        model.addAttribute("pojistenci", 1);
        model.addAttribute("mojePojisteni", "Moje pojištění ");


        return "pages/pojistenci/edit";
    }
    @Secured({"ROLE_ADMIN", "ROLE_USER"})
    @PostMapping("edit/{pojistenecId}")
    public String editPojistenec(
            @PathVariable long pojistenecId,
            @Valid PojistenecDTO pojistenec,
            BindingResult result, Model model,
            RedirectAttributes redirectAttributes
    ) {
        if (result.hasErrors())
            return renderEditForm(pojistenecId, pojistenec, model);

        pojistenec.setPojistenecId(pojistenecId);
        pojistenecService.edit(pojistenec);
        redirectAttributes.addFlashAttribute("success", "Pojištěnec byl upraven.");

        UserEntity user = (UserEntity) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (user.isAdmin())
            return "redirect:/pojistenci/stranka/1";
        return "redirect:/pojistenci/";
    }
    @Secured("ROLE_ADMIN")
    @GetMapping("delete/{pojistenecId}")
    public String deletePojistenec(@PathVariable long pojistenecId,
                                   RedirectAttributes redirectAttributes)
    {
        pojistenecService.remove(pojistenecId);
        redirectAttributes.addFlashAttribute("success", "Pojištěnec byl smazán.");

        return "redirect:/pojistenci/stranka/1";
    }



    @ExceptionHandler({PojistenecNotFoundException.class})
    public String handlePojistenecNotFoundException(
            RedirectAttributes redirectAttributes
    ) {
        redirectAttributes.addFlashAttribute("error", "Pojištěnec nenalezen.");
        return "redirect:/pojistenci/stranka/1";
    }

}
