package org.example.controllers;

import org.example.data.entities.UserEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/")
public class HomeController {

    @GetMapping
    public String renderIndex() {
        return "pages/home/index";
    }
    @Secured({"ROLE_ADMIN", "ROLE_USER"})
    @GetMapping ("home")
    public String renderIndex(Model model) {
        UserEntity user = (UserEntity) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (user.getPojistenecEntity() == null) {
            if (!user.isAdmin())
              model.addAttribute("novy", "Nový pojištěnec");
            if (!user.isAdmin())
        model.addAttribute("novyPojistenec", "Nový pojištěnec");}
        else {
            model.addAttribute("mojePojisteni", "Moje pojištění ");
            model.addAttribute("pojistenecId", user.getPojistenecEntity().getPojistenecId());}
        return "pages/home/index";
    }

    @GetMapping ("home/credits")
    public String renderCredits(Model model) {
        UserEntity user = (UserEntity) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (user.getPojistenecEntity() == null) {
            model.addAttribute("novy", "Nový pojištěnec");
            if (!user.isAdmin())
            model.addAttribute("novyPojistenec", "Nový pojištěnec");}
        model.addAttribute("credits", "1");
        if (user.getPojistenecEntity() != null)
        model.addAttribute("mojePojisteni", "Moje pojištění ");
        return "pages/home/credits";
    }
}
