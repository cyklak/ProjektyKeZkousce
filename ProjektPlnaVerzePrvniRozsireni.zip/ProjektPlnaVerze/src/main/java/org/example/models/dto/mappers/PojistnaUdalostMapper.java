package org.example.models.dto.mappers;

import org.example.data.entities.PojisteniEntity;
import org.example.data.entities.PojistnaUdalostEntity;
import org.example.models.dto.PojisteniDTO;
import org.example.models.dto.PojistnaUdalostDTO;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface PojistnaUdalostMapper {

    PojistnaUdalostEntity toEntity(PojistnaUdalostDTO source);

    PojistnaUdalostDTO toDTO(PojistnaUdalostEntity source);

    void updatePojistnaUdalostDTO(PojistnaUdalostDTO source, @MappingTarget PojistnaUdalostDTO target);

    void updatePojistnaUdalostEntity(PojistnaUdalostDTO source, @MappingTarget PojistnaUdalostEntity target);
}
