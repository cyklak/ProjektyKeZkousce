package org.example.models.services;

import org.example.data.entities.PojistenecEntity;
import org.example.data.entities.PojisteniEntity;
import org.example.data.entities.PojistnaUdalostEntity;
import org.example.data.entities.UserEntity;
import org.example.data.repositories.PojistenecRepository;
import org.example.data.repositories.PojisteniRepository;
import org.example.data.repositories.PojistnaUdalostRepository;
import org.example.models.dto.PojistenecDTO;
import org.example.models.dto.PojisteniDTO;
import org.example.models.dto.PojistnaUdalostDTO;
import org.example.models.dto.mappers.PojisteniMapper;
import org.example.models.dto.mappers.PojistnaUdalostMapper;
import org.example.models.exceptions.PojisteniNotFoundException;
import org.example.models.exceptions.UdalostNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class PojistnaUdalostServiceImpl implements PojistnaUdalostService {

    @Autowired
    private PojisteniRepository pojisteniRepository;

    @Autowired
    private PojistenecRepository pojistenecRepository;

    @Autowired
    private PojisteniMapper pojisteniMapper;

    @Autowired
    private PojisteniService pojisteniService;
    @Autowired
    private PojistnaUdalostMapper udalostMapper;

    @Autowired
    private PojistnaUdalostRepository udalostRepository;


    @Override
    public void create(PojistnaUdalostDTO udalost, Long pojistenecId) {
        List<Long> pojisteniIds = new ArrayList<>();
        for(Long pojisteniId: udalost.getPojisteniIds()) {
            PojisteniDTO pojisteni =  pojisteniService.getById(pojisteniId);
            if (((pojisteni.getPlatnostOd().isBefore(udalost.getDatumUdalosti())) || pojisteni.getPlatnostOd().isEqual(udalost.getDatumUdalosti())) && (pojisteni.getPlatnostDo().isAfter(udalost.getDatumUdalosti()) || pojisteni.getPlatnostDo().isEqual(udalost.getDatumUdalosti())))
                pojisteniIds.add(pojisteniId);

        }
        if (pojisteniIds.isEmpty())
            return;
        udalost.getPojisteniIds().clear();
        udalost.setPojisteniIds(pojisteniIds);
        PojistnaUdalostEntity udalostEntity = udalostMapper.toEntity(udalost);
        udalostEntity.setPojistenecId(pojistenecId);
        udalostEntity.setPojisteni(new ArrayList<>());
        for (Long pojisteniId : udalost.getPojisteniIds()) {
            udalostEntity.getPojisteni().add(pojisteniService.getPojisteniEntity(pojisteniId));
        }
        udalostRepository.save(udalostEntity);

        for (PojisteniEntity pojisteni : udalostEntity.getPojisteni()) {
            List<PojistnaUdalostEntity> pojistnaUdalost = pojisteni.getSeznamUdalosti();
            pojistnaUdalost.add(udalostEntity);
            pojisteni.setSeznamUdalosti(pojistnaUdalost);
            pojisteniRepository.save(pojisteni);
        }

    }

    @Override
    public List<PojistnaUdalostDTO> getUdalosti(int currentPage) {
        Page<PojistnaUdalostEntity> pageOfPeople = udalostRepository.findAll(PageRequest.of(currentPage, 10));
        List<PojistnaUdalostEntity> udalostEntities = pageOfPeople.getContent();
        List<PojistnaUdalostDTO> result = new ArrayList<>();
        for (PojistnaUdalostEntity e : udalostEntities) {
            result.add(udalostMapper.toDTO(e));
        }
        return result;
    }

    @Override
    public PojistnaUdalostDTO getById(long pojistnaUdalostId) {
        PojistnaUdalostEntity fetchedUdalost = getUdalostOrThrow(pojistnaUdalostId);

        return udalostMapper.toDTO(fetchedUdalost);
    }

    private PojistnaUdalostEntity getUdalostOrThrow(long pojistnaUdalostID) {
        return udalostRepository
                .findById(pojistnaUdalostID)
                .orElseThrow(UdalostNotFoundException::new);
    }

    @Override
    public List<PojistnaUdalostDTO> getUdalostibyPojistenecId(int currentPage, Long pojistenecId) {
        Page<PojistnaUdalostEntity> pageOfPeople = udalostRepository.findAllBypojistenecId(PageRequest.of(currentPage, 10), pojistenecId);
        List<PojistnaUdalostEntity> udalostEntities = pageOfPeople.getContent();
        List<PojistnaUdalostDTO> result = new ArrayList<>();
        for (PojistnaUdalostEntity e : udalostEntities) {
            result.add(udalostMapper.toDTO(e));
        }
        return result;
    }

    @Override
    public void edit(PojistnaUdalostDTO udalostDTO, Long pojistenecId) {
        PojistnaUdalostEntity entity = udalostRepository.findById(udalostDTO.getPojistnaUdalostId()).orElseThrow();
        List<PojisteniEntity> seznamPojisteni = entity.getPojisteni();
        List<Long> pojisteniIds = new ArrayList<>();
        for (PojisteniEntity jdenoPojisteni: seznamPojisteni) {
            pojisteniIds.add(jdenoPojisteni.getPojisteniId());
        }

        List<Long> pojisteniIdcka = new ArrayList<>();
        for(Long pojisteniId: udalostDTO.getPojisteniIds()) {
            PojisteniDTO pojisteni =  pojisteniService.getById(pojisteniId);
            if (((pojisteni.getPlatnostOd().isBefore(udalostDTO.getDatumUdalosti())) || pojisteni.getPlatnostOd().isEqual(udalostDTO.getDatumUdalosti())) && (pojisteni.getPlatnostDo().isAfter(udalostDTO.getDatumUdalosti()) || pojisteni.getPlatnostDo().isEqual(udalostDTO.getDatumUdalosti())))
                pojisteniIdcka.add(pojisteniId);

        }
        if (pojisteniIdcka.isEmpty())
            return;
        udalostDTO.getPojisteniIds().clear();
        udalostDTO.setPojisteniIds(pojisteniIdcka);

        PojistnaUdalostEntity fetchedUdalost = getUdalostOrThrow(udalostDTO.getPojistnaUdalostId());
        udalostMapper.updatePojistnaUdalostEntity(udalostDTO, fetchedUdalost);
        List<PojisteniEntity> pojisteni = new ArrayList<>();
        for (Long pojisteniId: udalostDTO.getPojisteniIds()) {
            pojisteni.add(pojisteniRepository.findById(pojisteniId).orElseThrow());
        }
        fetchedUdalost.setPojisteni(pojisteni);
        fetchedUdalost.setPojistenecId(pojistenecId);
        udalostRepository.save(fetchedUdalost);

        for (Long jednoPojisteni: pojisteniIds) {
           PojisteniEntity entita = pojisteniRepository.findById(jednoPojisteni).orElseThrow();
           if (!pojisteni.contains(entita)) {
               entita.getSeznamUdalosti().remove(fetchedUdalost);
               pojisteniRepository.save(entita);
           }
           for (PojisteniEntity entity2: pojisteni) {
               List<PojistnaUdalostEntity> seznamUdalosti = entity2.getSeznamUdalosti();
               if (!seznamUdalosti.contains(fetchedUdalost)) {
               seznamUdalosti.add(fetchedUdalost);}
               entity2.setSeznamUdalosti(seznamUdalosti);
               pojisteniRepository.save(entity2);
               }
           }
        }
    @Override
    public void remove(long udalostId) {
        PojistnaUdalostEntity fetchedEntity = getUdalostOrThrow(udalostId);
        List<PojisteniEntity> pojisteni = fetchedEntity.getPojisteni();
        for (PojisteniEntity jednoPojisteni: pojisteni) {
            jednoPojisteni.getSeznamUdalosti().remove(fetchedEntity);
            pojisteniRepository.save(jednoPojisteni);
        }
        udalostRepository.delete(fetchedEntity);


    }

    }


