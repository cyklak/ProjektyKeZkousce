package org.example.models.services;

import org.example.data.entities.PojistenecEntity;
import org.example.data.entities.UserEntity;
import org.example.models.dto.PojistenecDTO;

import java.util.List;

public interface PojistenecService {
    PojistenecEntity create(PojistenecDTO pojistenec, UserEntity entity);

    List<PojistenecDTO> getAll();

    PojistenecDTO getById(long pojistenecId);

    void edit(PojistenecDTO pojistenec);

    void remove(long pojistenecId);

    List<PojistenecDTO> getPojistenci(int currentPage);
}
