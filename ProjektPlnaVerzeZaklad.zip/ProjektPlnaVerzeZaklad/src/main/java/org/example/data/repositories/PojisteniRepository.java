package org.example.data.repositories;

import org.example.data.entities.PojisteniEntity;
import org.springframework.data.repository.CrudRepository;

public interface PojisteniRepository extends CrudRepository<PojisteniEntity, Long> {
}
