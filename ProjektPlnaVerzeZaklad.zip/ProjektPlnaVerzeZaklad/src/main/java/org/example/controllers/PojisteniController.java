package org.example.controllers;

import jakarta.validation.Valid;
import org.example.models.dto.PojistenecDTO;
import org.example.models.dto.PojisteniDTO;
import org.example.models.dto.mappers.PojistenecMapper;
import org.example.models.dto.mappers.PojisteniMapper;
import org.example.models.exceptions.PojisteniNotFoundException;
import org.example.models.services.PojistenecService;
import org.example.models.services.PojisteniService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/pojisteni/")
public class PojisteniController {

    @Autowired
    private PojistenecMapper pojistenecMapper;
    @Autowired
    private PojistenecService pojistenecService;

    @Autowired
    private PojisteniMapper pojisteniMapper;
    @Autowired
    private PojisteniService pojisteniService;

    @Secured("ROLE_ADMIN")
    @GetMapping("{pojistenecId}/novePojisteni")
    public String renderNovePojisteni(
            @PathVariable long pojistenecId, @ModelAttribute PojisteniDTO pojisteni,
            Model model
    ) {
        PojistenecDTO pojistenec = pojistenecService.getById(pojistenecId);
        model.addAttribute("pojistenec", pojistenec);

        return "pages/pojisteni/novePojisteni";
    }
    @Secured("ROLE_ADMIN")
    @PostMapping("{pojistenecId}/novePojisteni")
    public String createNovePojisteni(
            @Valid @ModelAttribute PojisteniDTO pojisteni, BindingResult result, @PathVariable long pojistenecId, Model model,
            RedirectAttributes redirectAttributes
    ) {
        if (result.hasErrors())
            return renderNovePojisteni(pojistenecId, pojisteni, model);
        pojisteni.setPojistenec(pojistenecService.getById(pojistenecId));
        pojisteniService.create(pojisteni);
        redirectAttributes.addFlashAttribute("success", "Pojištění bylo vytvořeno.");

        return "redirect:/pojistenci/{pojistenecId}";
    }
    @Secured("ROLE_ADMIN")
    @GetMapping("{pojistenecId}/delete/{pojisteniId}")
    public String deletePojisteni(@PathVariable long pojistenecId, @PathVariable long pojisteniId,
                                   RedirectAttributes redirectAttributes)
    {
        pojisteniService.remove(pojisteniId);
        redirectAttributes.addFlashAttribute("success", "Pojištění bylo smazáno.");

        return "redirect:/pojistenci/{pojistenecId}";
    }
    @Secured("ROLE_ADMIN")
    @GetMapping("{pojistenecId}/edit/{pojisteniId}")
    public String renderEditForm(
            @PathVariable Long pojistenecId, @PathVariable long pojisteniId,
            PojisteniDTO pojisteni, Model model
    ) {
        PojisteniDTO fetchedPojisteni = pojisteniService.getById(pojisteniId);
        PojistenecDTO pojistenec = pojistenecService.getById(pojistenecId);
        model.addAttribute("pojistenec", pojistenec);
        pojisteniMapper.updatePojisteniDTO(fetchedPojisteni, pojisteni);

        return "pages/pojisteni/edit";
    }
    @Secured("ROLE_ADMIN")
    @PostMapping("{pojistenecId}/edit/{pojisteniId}")
    public String editPojisteni(
            @PathVariable long pojistenecId, @PathVariable long pojisteniId,
            @Valid PojisteniDTO pojisteni,
            BindingResult result,
            RedirectAttributes redirectAttributes, Model model
    ) {
        if (result.hasErrors())
            return renderEditForm(pojistenecId, pojisteniId, pojisteni, model);
        pojisteni.setPojisteniId(pojisteniId);
        pojisteni.setPojistenec(pojistenecService.getById(pojistenecId));
        pojisteniService.edit(pojisteni);
        redirectAttributes.addFlashAttribute("success", "Pojištění bylo upraveno.");

        return "redirect:/pojistenci/{pojistenecId}";
    }
    @Secured("ROLE_ADMIN")
    @GetMapping("{pojistenecId}/detail/{pojisteniId}")
    public String renderDetail(
            @PathVariable long pojistenecId, @PathVariable long pojisteniId,
            Model model
    ) {
        PojistenecDTO pojistenec = pojistenecService.getById(pojistenecId);
        model.addAttribute("pojistenec", pojistenec);
        PojisteniDTO pojisteni = pojisteniService.getById(pojisteniId);
        model.addAttribute("pojisteni", pojisteni);

        return "pages/pojisteni/detail";
    }

    @ExceptionHandler({PojisteniNotFoundException.class})
    public String handlePojisteniNotFoundException(
            RedirectAttributes redirectAttributes
    ) {
        redirectAttributes.addFlashAttribute("error", "Pojištění nenalezeno.");
        return "redirect:/pojistenci/";
    }

}
