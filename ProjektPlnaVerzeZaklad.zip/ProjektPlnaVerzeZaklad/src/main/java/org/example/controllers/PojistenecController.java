package org.example.controllers;
import jakarta.validation.Valid;
import org.example.data.repositories.PojistenecRepository;
import org.example.models.dto.PojistenecDTO;
import org.example.models.dto.PojisteniDTO;
import org.example.models.dto.mappers.PojistenecMapper;
import org.example.models.dto.mappers.PojisteniMapper;
import org.example.models.exceptions.PojistenecNotFoundException;
import org.example.models.services.PojistenecService;
import org.example.models.services.PojisteniService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;


@Controller
@RequestMapping("/pojistenci/")
public class PojistenecController {
    @Autowired
    private PojistenecMapper pojistenecMapper;
    @Autowired
    private PojistenecService pojistenecService;

    @Autowired
    private PojisteniMapper pojisteniMapper;

    @Autowired
    private PojistenecRepository pojistenecRepository;
    @Autowired
    private PojisteniService pojisteniService;

    @Secured("ROLE_ADMIN")
    @GetMapping("stranka/{currentPage}")
    public String renderIndex(Model model,  @PathVariable int currentPage) {
        List<PojistenecDTO> pojistenci = pojistenecService.getPojistenci(currentPage -1);
        model.addAttribute("pojistenci", pojistenci);
        if (pojistenecRepository.count() > 10) {
            model.addAttribute("soucasnaStrana", currentPage);}
        if (pojistenecRepository.count() > (currentPage*10)) {
            model.addAttribute("pristiStrana", currentPage + 1);
            if (pojistenecRepository.count() > (currentPage*10) + 10) {
                model.addAttribute("prespristiStrana", currentPage + 2);}
        }
        if (currentPage > 1) {
            model.addAttribute("predchoziStrana", currentPage - 1);
            if (currentPage > 2) {
                model.addAttribute("predpredchoziStrana", currentPage - 2);
            }
        }
        return "pages/pojistenci/index";
    }
    @Secured("ROLE_ADMIN")
    @GetMapping("novyPojistenec")
    public String renderNovyPojistenec(@ModelAttribute PojistenecDTO pojistenec) {
        return "pages/pojistenci/novyPojistenec";
    }
    @Secured("ROLE_ADMIN")
    @PostMapping("novyPojistenec")
    public String createNovyPojistenec(
            @Valid @ModelAttribute PojistenecDTO pojistenec,
            BindingResult result,
            RedirectAttributes redirectAttributes
    ) {
        if (result.hasErrors())
            return renderNovyPojistenec(pojistenec);

        pojistenecService.create(pojistenec);
        redirectAttributes.addFlashAttribute("success", "Pojištěnec byl vytvořen.");

        return "redirect:/pojistenci/stranka/1";
    }
    @Secured("ROLE_ADMIN")
    @GetMapping("{pojistenecId}")
    public String renderDetail(
            @PathVariable long pojistenecId,
            Model model
    ) {
        PojistenecDTO pojistenec = pojistenecService.getById(pojistenecId);
        model.addAttribute("pojistenec", pojistenec);
        List<PojisteniDTO> pojisteni = pojisteniService.getAllByPojistenecId(pojistenecId);
        model.addAttribute("pojisteni", pojisteni);

        return "pages/pojistenci/detail";
    }
    @Secured("ROLE_ADMIN")
    @GetMapping("edit/{pojistenecId}")
    public String renderEditForm(
            @PathVariable Long pojistenecId,
            PojistenecDTO pojistenec
    ) {
        PojistenecDTO fetchedPojistenec = pojistenecService.getById(pojistenecId);
        pojistenecMapper.updatePojistenecDTO(fetchedPojistenec, pojistenec);

        return "pages/pojistenci/edit";
    }
    @Secured("ROLE_ADMIN")
    @PostMapping("edit/{pojistenecId}")
    public String editPojistenec(
            @PathVariable long pojistenecId,
            @Valid PojistenecDTO pojistenec,
            BindingResult result,
            RedirectAttributes redirectAttributes
    ) {
        if (result.hasErrors())
            return renderEditForm(pojistenecId, pojistenec);

        pojistenec.setPojistenecId(pojistenecId);
        pojistenecService.edit(pojistenec);
        redirectAttributes.addFlashAttribute("success", "Pojištěnec byl upraven.");

        return "redirect:/pojistenci/{pojistenecId}";
    }
    @Secured("ROLE_ADMIN")
    @GetMapping("delete/{pojistenecId}")
    public String deletePojistenec(@PathVariable long pojistenecId,
                                   RedirectAttributes redirectAttributes)
    {
        pojistenecService.remove(pojistenecId);
        redirectAttributes.addFlashAttribute("success", "Pojištěnec byl smazán.");

        return "redirect:/pojistenci/stranka/1";
    }



    @ExceptionHandler({PojistenecNotFoundException.class})
    public String handlePojistenecNotFoundException(
            RedirectAttributes redirectAttributes
    ) {
        redirectAttributes.addFlashAttribute("error", "Pojištěnec nenalezen.");
        return "redirect:/pojistenci/stranka/1";
    }

}
