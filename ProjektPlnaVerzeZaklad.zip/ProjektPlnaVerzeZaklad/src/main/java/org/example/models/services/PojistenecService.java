package org.example.models.services;

import org.example.models.dto.PojistenecDTO;

import java.util.List;

public interface PojistenecService {
    void create(PojistenecDTO pojistenec);

    List<PojistenecDTO> getAll();

    PojistenecDTO getById(long pojistenecId);

    void edit(PojistenecDTO pojistenec);

    void remove(long pojistenecId);

    List<PojistenecDTO> getPojistenci(int currentPage);
}
