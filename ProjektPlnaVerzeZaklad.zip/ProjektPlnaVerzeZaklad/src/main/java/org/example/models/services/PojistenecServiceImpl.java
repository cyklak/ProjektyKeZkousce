package org.example.models.services;

import org.example.data.entities.PojistenecEntity;
import org.example.data.repositories.PojistenecRepository;
import org.example.models.dto.PojistenecDTO;
import org.example.models.dto.PojisteniDTO;
import org.example.models.dto.mappers.PojistenecMapper;
import org.example.models.exceptions.PojistenecNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.StreamSupport;

@Service
public class PojistenecServiceImpl implements PojistenecService {

    @Autowired
    private PojistenecRepository pojistenecRepository;
    @Autowired
    private PojistenecMapper pojistenecMapper;

    @Autowired
    private PojisteniService pojisteniService;


    @Override
    public void create(PojistenecDTO pojistenec) {
        PojistenecEntity newPojistenec = pojistenecMapper.toEntity(pojistenec);

        pojistenecRepository.save(newPojistenec);
    }

    @Override
    public List<PojistenecDTO> getAll() {
        return StreamSupport.stream(pojistenecRepository.findAll().spliterator(), false)
                .map(i -> pojistenecMapper.toDTO(i))
                .toList();
    }
    @Override
    public List<PojistenecDTO> getPojistenci(int currentPage) {
        Page<PojistenecEntity> pageOfPeople = pojistenecRepository.findAll(PageRequest.of(currentPage, 10));
        List<PojistenecEntity> personEntities = pageOfPeople.getContent();
        List<PojistenecDTO> result = new ArrayList<>();
        for (PojistenecEntity e : personEntities) {
            result.add(pojistenecMapper.toDTO(e));
        }
        return result;
    }

    @Override
    public PojistenecDTO getById(long pojistenecId) {
        PojistenecEntity fetchedPojistenec = getPojistenecOrThrow(pojistenecId);

        return pojistenecMapper.toDTO(fetchedPojistenec);
    }

    @Override
    public void edit(PojistenecDTO pojistenec) {
        PojistenecEntity fetchedPojistenec = getPojistenecOrThrow(pojistenec.getPojistenecId());

        pojistenecMapper.updatePojistenecEntity(pojistenec, fetchedPojistenec);
        pojistenecRepository.save(fetchedPojistenec);
    }

    private PojistenecEntity getPojistenecOrThrow(long pojistenecID) {
        return pojistenecRepository
                .findById(pojistenecID)
                .orElseThrow(PojistenecNotFoundException::new);
    }

    @Override
    public void remove(long pojistenecId) {
        List<PojisteniDTO> seznamPojisteni = pojisteniService.getAllByPojistenecId(pojistenecId);
        for (PojisteniDTO pojisteni: seznamPojisteni) {
           pojisteniService.remove(pojisteni.getPojisteniId());}
            PojistenecEntity fetchedEntity = getPojistenecOrThrow(pojistenecId);
            pojistenecRepository.delete(fetchedEntity);
    }

}