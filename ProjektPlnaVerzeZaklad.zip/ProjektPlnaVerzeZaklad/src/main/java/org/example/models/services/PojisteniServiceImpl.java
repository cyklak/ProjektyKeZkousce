package org.example.models.services;

import org.example.data.entities.PojisteniEntity;
import org.example.data.repositories.PojistenecRepository;
import org.example.data.repositories.PojisteniRepository;
import org.example.models.dto.PojisteniDTO;
import org.example.models.dto.mappers.PojisteniMapper;
import org.example.models.exceptions.PojisteniNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PojisteniServiceImpl implements PojisteniService {

    @Autowired
    private PojisteniRepository pojisteniRepository;

    @Autowired
    private PojistenecRepository pojistenecRepository;

    @Autowired
    private PojisteniMapper pojisteniMapper;
    @Override
    public void create(PojisteniDTO pojisteni) {
        PojisteniEntity newPojisteni = pojisteniMapper.toEntity(pojisteni);
        pojisteniRepository.save(newPojisteni);
    }

     @Override
     public List<PojisteniDTO> getAllByPojistenecId(Long pojistenecId) {
        List<PojisteniEntity> seznamPojisteni =  pojistenecRepository.findById(pojistenecId).orElseThrow().getSeznamPojisteni();
        List<PojisteniDTO> pojisteniDTO = new ArrayList<>();
        for (PojisteniEntity pojisteni: seznamPojisteni) {
            pojisteniDTO.add(pojisteniMapper.toDTO(pojisteni));
     }
     return pojisteniDTO;
      }

    @Override
    public PojisteniDTO getById(long pojisteniId) {
        PojisteniEntity fetchedPojisteni = getPojisteniOrThrow(pojisteniId);

        return pojisteniMapper.toDTO(fetchedPojisteni);
    }

    private PojisteniEntity getPojisteniOrThrow(long pojisteniID) {
        return pojisteniRepository
                .findById(pojisteniID)
                .orElseThrow(PojisteniNotFoundException::new);
    }

    @Override
    public void remove(long pojisteniId) {
        PojisteniEntity fetchedEntity = getPojisteniOrThrow(pojisteniId);
        pojisteniRepository.delete(fetchedEntity);
    }

    @Override
    public void edit(PojisteniDTO pojisteni) {
        PojisteniEntity fetchedPojisteni = getPojisteniOrThrow(pojisteni.getPojisteniId());

        pojisteniMapper.updatePojisteniEntity(pojisteni, fetchedPojisteni);
        pojisteniRepository.save(fetchedPojisteni);
    }
}
