let soucasnaStrana = 1;
let radky = [];
let tlacitkaLista;
let nextPage;
let previousPage;
let currentPage;
let paginace;

window.onload = function() {
paginace = document.getElementById("paginace");
if (paginace)
    smazTabulku();
}

function smazTabulku() {
    let tabulka = document.getElementById("tabulka");
 radky = document.querySelectorAll("tbody > tr");
 if (radky.length> 5) {
    for(let i = radky.length - 1; i>=0; i--) {
    tabulka.removeChild(radky[i]);
 }
 tlacitkaLista = document.getElementById("paginace");
 paginuj(soucasnaStrana);
 }
}

function paginuj(soucasnaStrana) {
   if (previousPage != null)
   tlacitkaLista.removeChild(previousPage);
   if (currentPage != null)
   tlacitkaLista.removeChild(currentPage);
   if (nextPage != null)
   tlacitkaLista.removeChild(nextPage);
 for (let i = (soucasnaStrana-1)*5; i <= ((soucasnaStrana-1)*5) + 4; i++) {
   if (radky[i] != null)
   tabulka.appendChild(radky[i]);
}

if(soucasnaStrana>1) {
   previousPage = document.createElement("button");
   previousPage.setAttribute("class", "page-link");
   previousPage.innerText = soucasnaStrana - 1;
   tlacitkaLista.appendChild(previousPage);
   previousPage.onclick = function() {
      for (let i = (soucasnaStrana-1)*5; i <= ((soucasnaStrana-1)*5) + 4; i++) {
         if (radky[i] != null)
         tabulka.removeChild(radky[i]);}
      soucasnaStrana = soucasnaStrana - 1;
      paginuj(soucasnaStrana);
   }
}
else {
   previousPage=null;
}

if(radky.length>1) {
   currentPage = document.createElement("button");
   currentPage.setAttribute("class", "page-link");
   currentPage.innerText = soucasnaStrana;
   tlacitkaLista.appendChild(currentPage); 
   }
else {
   currentPage=null;
}


if(radky.length > soucasnaStrana*5) {
   nextPage = document.createElement("button");
   nextPage.setAttribute("class", "page-link");
   nextPage.innerText = soucasnaStrana + 1;
   tlacitkaLista.appendChild(nextPage);
   nextPage.onclick = function() {
      for (let i = (soucasnaStrana-1)*5; i <= ((soucasnaStrana-1)*5) + 4; i++) {
         if (radky[i] != null)
         tabulka.removeChild(radky[i]);}
      soucasnaStrana = soucasnaStrana + 1;
      paginuj(soucasnaStrana);
   }
}
else {
   nextPage=null;
}


}

