/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cz.itnetwork.projektkezkousce;

/**
 *
 * @author honza
 */
public class Pojisteny {

    private String jmeno;
    private String prijmeni;
    private int vek;
    private String telefonniCislo;

    public Pojisteny(String jmeno, String prijmeni, int vek, String telefonniCislo) {
        this.jmeno = jmeno;
        this.prijmeni = prijmeni;
        this.vek = vek;
        this.telefonniCislo = telefonniCislo;
    }

    /**
     * @return the jmeno
     */
    public String getJmeno() {
        return jmeno;
    }

    /**
     * @return the prijmeni
     */
    public String getPrijmeni() {
        return prijmeni;
    }

    @Override
    public String toString() {
        String jmenoPojisteneho = jmeno + "                          ";
        jmenoPojisteneho = jmenoPojisteneho.substring(0, 25);

        String prijmeniPojisteneho = prijmeni + "                               ";
        prijmeniPojisteneho = prijmeniPojisteneho.substring(0, 30);

        return jmenoPojisteneho + prijmeniPojisteneho + vek + "      " + telefonniCislo;

    }

}
