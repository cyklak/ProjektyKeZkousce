/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package cz.itnetwork.projektkezkousce;

import java.util.Scanner;

/**
 *
 * @author honza
 */
public class ProjektKeZkousce {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in, "Windows-1250");
        Evidence evidence = new Evidence();
        int volba = 1;
        // hlavní cyklus
        do {
            evidence.VytiskniMenu();
            System.out.print("Zadejte příkaz: ");
            while (true) {
                try {
                    volba = Integer.parseInt(sc.nextLine());
                    break;
                } catch (Exception ex) {
                    System.out.println("Nesprávně zadáno, zadejte prosím znovu");
                }
            }
            System.out.println();
            // reakce na volbu
            switch (volba) {
                case 1:
                    evidence.pridejPojisteneho();
                    break;
                case 2:
                    evidence.zobrazVsechnyPojistene();
                    break;
                case 3:
                    evidence.vyhledejPojisteneho();
                    break;
                case 4:
                    System.out.println("Zavírám evidenci");
                    break;
                default:
                    System.out.println("Neplatná volba, stiskněte libovolnou klávesu a opakujte volbu.");
                    break;
            }
        } while (volba != 4);
    }
}
