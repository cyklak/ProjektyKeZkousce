/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cz.itnetwork.projektkezkousce;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author honza
 */
public class Evidence {

    private ArrayList<Pojisteny> pojisteni = new ArrayList<>();
    private Scanner sc = new Scanner(System.in, "Windows-1250");

    void VytiskniMenu() {
        System.out.println("--------------------------------");
        System.out.println("Evidence pojištěných");
        System.out.println("--------------------------------");
        System.out.println();
        System.out.println("1 - Přidat nového pojištěného");
        System.out.println("2 - Vypsat všechny pojištěné");
        System.out.println("3 - Vyhledat pojištěného");
        System.out.println("4 - Konec");

    }

    public void pridejPojisteneho() {
        System.out.println("Zadejte jméno pojištěného:");
        String jmeno = sc.nextLine();
        System.out.println("Zadejte příjmení:");
        String prijmeni = sc.nextLine();
        System.out.println("Zadejte telefonni cislo:");
        String telCislo = sc.nextLine();
        System.out.println("Zadejte věk:");
        int vek = 0;
        while (true) {
            try {
                vek = Integer.parseInt(sc.nextLine());
                break;
            } catch (Exception ex) {
                System.out.println("Nesprávně zadáno, zadejte prosím znovu");
            }
        }
        pojisteni.add(new Pojisteny(jmeno, prijmeni, vek, telCislo));
        System.out.println();
        System.out.println("Data byla uložena. Pokračujte stisknutím klávesy Enter...");
        sc.nextLine();
    }

    public void zobrazVsechnyPojistene() {
        if (!pojisteni.isEmpty()) {
            for (Pojisteny pojisteny : pojisteni) {
                System.out.println(pojisteny);
            }
        } else {
            System.out.println("V databázi nejsou žádné záznamy");
        }

        System.out.println();
        System.out.println("Pokračujte stisknutím klávesy Enter...");
        sc.nextLine();
    }

    public void vyhledejPojisteneho() {
        System.out.println("Zadejte jméno pojištěného:");
        String jmeno = sc.nextLine();
        System.out.println("Zadejte příjmení:");
        String prijmeni = sc.nextLine();
        System.out.println();
        boolean existuje = false;
        for (Pojisteny pojisteny : pojisteni) {
            if (jmeno.equals(pojisteny.getJmeno()) && prijmeni.equals(pojisteny.getPrijmeni())) {
                System.out.println(pojisteny);
                existuje = true;
            }
        }
        if (!existuje) {
            System.out.println("Tato osoba v není v databázi");
        }
        System.out.println();
        System.out.println("Pokračujte stisknutím klávesy Enter...");
        sc.nextLine();
    }

}
